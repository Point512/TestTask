<?
$MESS["MAIN_COMMENT_OBJECT_ID"] = "ID объекта комментирования";
$MESS["MAIN_COMMENT_CAN_MODIFY"] = "Разрешить редактирование комментария";
$MESS["MAIN_COMMENT_VISUAL_PARAMS"] = "Визуальные настройки";
$MESS["MAIN_COMMENT_COUNT"] = "Количество комментариев на странице";
$MESS["MAIN_COMMENT_MAX_DEPTH"] = "Максимальный уровень вложенности";
$MESS["MAIN_COMMENT_ACTIVE_DATE_FORMAT"] = "Формат показа даты";
$MESS["MAIN_COMMENT_ACCESS_FIELDS_GROUP_NAME"] = "Доступ";
$MESS["MAIN_COMMENT_PREMODERATION"] = "Включить премодерацию";
$MESS["MAIN_COMMENT_LEGAL"] = "Требовать согласиться с правилами";
$MESS["MAIN_COMMENT_LEGAL_TEXT"] = "Текст галочки о согласии с правилами";
$MESS["MAIN_COMMENT_LEGAL_TEXT_DEFAULT"] = "Я согласен с правилами размещения сообщений на сайте.";
$MESS["MAIN_COMMENT_NONAUTHORIZED_CAN_COMMENT"] = "Разрешить неавторизованным пользователям добавлять комментарии";
$MESS["MAIN_COMMENT_REQUIRE_EMAIL"] = "Требовать e-mail у неавторизованных пользователей";
$MESS["MAIN_COMMENT_USE_CAPTCHA"] = "Показывать CAPTCHA неавторизованным пользователям";
$MESS["MAIN_COMMENT_LOAD_AVATAR"] = "Разрешить загрузить аватар";
$MESS["MAIN_COMMENT_LOAD_MARK"] = "Разрешить оценивать";
$MESS["MAIN_COMMENT_LOAD_DIGNITY"] = "Разрешить Достоинства";
$MESS["MAIN_COMMENT_LOAD_FAULT"] = "Разрешить Недостатки";
$MESS["MAIN_COMMENT_ADDITIONAL"] = "Дополнительные свойства";
$MESS["MAIN_COMMENT_JQUERY"] = "Подключить jQuery (если не подключен)";
$MESS['MAIN_COMMENT_ALLOW_RATING'] = "Включить рейтинг";
$MESS["MAIN_COMMENT_AUTH_PATH"] = "Путь до страницы авторизации";
?>