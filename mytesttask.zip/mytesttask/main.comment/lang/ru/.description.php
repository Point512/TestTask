<?
$MESS["MAIN_COMMENT_NAME"] = "Комментарии";
$MESS["MAIN_COMMENT_DESC"] = "Комментарии";
?>