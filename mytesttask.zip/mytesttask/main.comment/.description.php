<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    "NAME" => "Древовидные комментарии тестовое задание",
    "DESCRIPTION" => "тестовое задание",
    "SORT" => 10,
    "CACHE_PATH" => "Y",
    "PATH" => array(
        "ID" => "com_tree_test_task",
        "NAME" => "Древовидные комментарии"
    ),
    "COMPLEX" => "N",
);
?>