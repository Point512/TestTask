<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var Array $arCurrentValues */

CModule::IncludeModule("iblock");

// типы инфоблоков
$arIBlockType = CIBlockParameters::GetIBlockTypes();

// инфоблоки выбранного типа
$arIBlock = [];
$iblockFilter = !empty($arCurrentValues['IBLOCK_TYPE'])
    ? ['TYPE' => $arCurrentValues['IBLOCK_TYPE'], 'ACTIVE' => 'Y']
    : ['ACTIVE' => 'Y'];

$rsIBlock = CIBlock::GetList(['SORT' => 'ASC'], $iblockFilter);
while ($arr = $rsIBlock->Fetch()) {
    $arIBlock[$arr['ID']] = '['.$arr['ID'].'] '.$arr['NAME'];
}
unset($arr, $rsIBlock, $iblockFilter);

//$test = '111';

$arComponentParameters = [

	"PARAMETERS" => [


        //Тип объекта комментирования. Тип: выпадающий список. Значения: "Элемент
        //инфоблока", "Страница".

        'OBJECT_TYPE' =>[
            'NAME' => "тип обьекта комментироваия",
            'TYPE' => 'LIST',
            'MULTIPLE' => 'N',
            'ADDITIONAL_VALUES' => 'N',
            "VALUES" => $arIBlockType,
            'PARENT' => 'BASE',
        ],

        //Объект комментирования. Тип: строка. В данном параметре будет указываться
        //объект комментирования. Если в предыдущем параметре выбрано "Элемент
        //инфоблока", то в данном поле администратором будет указываться ID элемента

		'OBJECT_ID' =>[
			'NAME' => "Обьект комментироваия",
			'TYPE' => 'INT',
			'MULTIPLE' => 'N',
			'ADDITIONAL_VALUES' => 'N',
			'PARENT' => 'BASE',
		],

		'MAX_DEPTH' => [
			'NAME' => "Уровень вложенности",
			'TYPE' => 'INT',
			'PARENT' => 'BASE',
			'ADDITIONAL_VALUES' => 'N',
			"DEFAULT" => '5',
		],

        "IBLOCK_TYPE" => [
            "PARENT" => "SETTINGS",
            "NAME" => "Тип инфоблока",
            "TYPE" => "LIST",
            "ADDITIONAL_VALUES" => "Y",
            "VALUES" => $arIBlockType,
            "REFRESH" => "Y"
        ],

        "IBLOCK_ID" => [
            "PARENT" => "SETTINGS",
            "NAME" => "Инфоблок",
            "TYPE" => "LIST",
            "ADDITIONAL_VALUES" => "Y",
            "VALUES" => $arIBlock,
            "REFRESH" => "Y"
        ],

	],
   // "CACHE_TIME" => ['DEFAULT' => 3600],
];


