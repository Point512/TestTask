<?php

use \Bitrix\Main\Application;
use \Bitrix\Main\Loader;
use \Bitrix\Main\Engine\Contract;
use \Bitrix\Main\Error;
use \Bitrix\Main\ErrorCollection;
use \Bitrix\Main\Config\Option;

/**
 * Bitrix vars
 *
 * @var array $arParams
 * @var array $arResult
 * @var CBitrixComponent $this
 * @global CMain $APPLICATION
 */

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

$this->setFrameMode(false);


class CommentsTree extends CBitrixComponent
{
    //стандартное, родное, битриксовое
    public function configureActions()
    {
        //если действия не нужно конфигурировать, то оставить пустым,  будет конфиг по умолчанию
        return [];
    }

    //скрипт для создания нужного ИБ, чтобы не созавать его руками start
    public function CreateIBlock($type = "Comments")
    {
        global $DB;
        if (!CModule::IncludeModule("iblock")) die();
        $r = false;

        $sids = array();
        $arQuery = CSite::GetList($sort = "sort", $order = "desc", array());
        while ($res = $arQuery->Fetch()) {
            $sids[] = $res["ID"];
        }

        $arTypes = CIBlockType::GetByID($type);
        if (!$arType = $arTypes->Fetch()) {
            $arFields = array(
                'ID' => $type,
                'SECTIONS' => 'Y',
                'IN_RSS' => 'N',
                'SORT' => 100,
                'LANG' => array(
                    'ru' => array(
                        'NAME' => "Comments",
                        'SECTION_NAME' => "Раздел",
                        'ELEMENT_NAME' => "Элемент"
                    )
                )
            );
            $obBlocktype = new CIBlockType;
            $DB->StartTransaction();
            $res = $obBlocktype->Add($arFields);
            if (!$res) {
                $DB->Rollback();
                echo 'Error: ' . $obBlocktype->LAST_ERROR . '<br />';
                die("TYPE_ERROR");
            } else
                $DB->Commit();
        }

        $arFields = array(
            "ACTIVE" => "Y",
            "NAME" => "Комментарии",
            "IBLOCK_TYPE_ID" => $type,
            "SITE_ID" => $sids,
            "GROUP_ID" => array("2" => "R", "1" => "X"),
            "INDEX_ELEMENT" => "N",
            "INDEX_SECTION" => "N"
        );
        $ib = new CIBlock();
        if ($r = $ib->Add($arFields)) {
            self::CheckIBlock($r);
        } else {
            echo 'Error: ' . $ib->LAST_ERROR . '<br />';
        }

        return $r;
    }
    public function CheckIBlock()
    {
        if (!CModule::IncludeModule("iblock")) die();
        $r = true;

        $iblock = CIBlock::GetByID($this->arParams['IBLOCK_ID'])->GetNext();
        if (!$iblock)
            $r = false;

        if ($r) {
            $arPropsIB = array();
            $res = CIBlock::GetProperties(5, array(), array());
            while ($res_arr = $res->Fetch())
                $arPropsIB[] = $res_arr["CODE"];

            $arProps = array();
            $arProps[] = array(
                "NAME" => "Объект комментирования",
                "ACTIVE" => "Y",
                "SORT" => "100",
                "CODE" => "OBJECT",
                "PROPERTY_TYPE" => "E",
                "IBLOCK_ID" => $this->arParams['IBLOCK_ID'],
                "WITH_DESCRIPTION" => "N",
            );
            $arProps[] = array(
                "NAME" => "Автор",
                "ACTIVE" => "Y",
                "SORT" => "200",
                "CODE" => "USER",
                "PROPERTY_TYPE" => "S",
                "USER_TYPE" => "UserID",
                "IBLOCK_ID" => $this->arParams['IBLOCK_ID'],
                "WITH_DESCRIPTION" => "N",
            );
            $arProps[] = array(
                "NAME" => "Вложенность",
                "ACTIVE" => "Y",
                "SORT" => "500",
                "CODE" => "DEPTH",
                "PROPERTY_TYPE" => "S",
                "IBLOCK_ID" => $this->arParams['IBLOCK_ID'],
                "WITH_DESCRIPTION" => "N",
            );
            $arProps[] = array(
                "NAME" => "Родитель",
                "ACTIVE" => "Y",
                "SORT" => "600",
                "CODE" => "PARENT",
                "PROPERTY_TYPE" => "E",
                "IBLOCK_ID" => $this->arParams['IBLOCK_ID'],
                "WITH_DESCRIPTION" => "N",
            );


            $iblockproperty = new CIBlockProperty;
            foreach ($arProps as $pr) {
                if (!in_array($pr["CODE"], $arPropsIB))
                    $PropertyID = $iblockproperty->Add($pr);
            }
        }
        return $r;
    }
    //скрипт для создания нужного ИБ, чтобы не созавать его руками end

    //битрисовый аякс и Jquery
    private function loadAjax()
    {
        CJSCore::Init(['ajax']);
    }
    private function loadJQuery()
    {
        CJSCore::Init(['jquery']);
    }
    //битрисовый аякс и Jquery

    //добавить, дополнить удалить start
    public function Add($arFields = array())
    {
        if (!CModule::IncludeModule("iblock")) die();

        $arF = array(
            "IBLOCK_ID" => $this->arParams['IBLOCK_ID'],
            "IBLOCK_SECTION_ID" => false,
            "ACTIVE" => $arFields["active"],
            "NAME" => $arFields["nonuser"],
            "PREVIEW_TEXT" => $arFields["text"],
            "PREVIEW_TEXT_TYPE" => "html",
            "PREVIEW_PICTURE" => $arFields["avatar"],
            "PROPERTY_VALUES" => array(
                "OBJECT" => $arFields["object"],
                "PARENT" => $arFields["parent"],
                "DEPTH" => $arFields["level"],
                "USER" => $arFields["author"],
                "NONUSER" => $arFields["nonuser"],
            ),
        );

        $el = new CIBlockElement();
        if ($id = $el->Add($arF))
            return $id;
        else {
            return false;
        }
    }
    public function Update($id, $text)
    {
        global $USER;

        if (intval($id) <= 0 || !$USER->IsAuthorized())
            return false;

        $arFilter = array(
            'ID' => $id,
            'IBLOCK_ID' => $this->arParams['IBLOCK_ID']
        );

        if (!$USER->IsAdmin())
            $arFilter['PROPERTY_USER_VALUE'] = $USER->GetID();

        $check = CIBlockElement::GetList(array(), $arFilter, array());
        if (intval($check) <= 0)
            return false;

        //Update
        $el = new CIBlockElement();
        if ($el->Update($id, array("PREVIEW_TEXT" => $text))) {
            return true;
        }
    }
    public function Delete($id)
    {
        if (!CModule::IncludeModule("iblock")) die();

        global $USER;
        $IblockId = $this->arParams['IBLOCK_ID'];
        //Ignore empty id and not authorized users
        if (intval($id) <= 0 || !$USER->IsAuthorized())
            return false;


        $arFilter = array(
            'ID' => $id,
            'IBLOCK_ID' => $IblockId
        );

        if (!$USER->IsAdmin())
            $arFilter['PROPERTY_USER_VALUE'] = $USER->GetID();


        $check = CIBlockElement::GetList(array(), $arFilter, array());
        if (intval($check) <= 0)
            return false;


        $arElem = CIBlockElement::GetList(array(), array("IBLOCK_ID" => $IblockId, "PROPERTY_PARENT" => $id), false, false, array("ID"));
        CIBlockElement::Delete($id);
        while ($resElem = $arElem->GetNext()) {
            self::Delete($resElem["ID"]);
        }

        return true;
    }
    //добавить, дополнить удалить end

    // Комментарии и дочерние комментарии start
    public function Show($arSelect = array(), $sort = array(), $arNavParams = false)
    {

//        $arResult["ITEMS"] = array();
//        $arResult["ELEMENTS"] = array();
        $arFilter = array(
            "IBLOCK_ID" => $this->arParams['IBLOCK_ID'],
            "PROPERTY_OBJECT" => $this->arParams["OBJECT_ID"],
            "PROPERTY_PARENT" => false,
            "ACTIVE" => "Y",
        );

        foreach (array("DATE_CREATE") as $s) {
            if (!in_array($s, $arSelect))
                $arSelect[] = $s;
        }
        $rsElement = CIBlockElement::GetList($sort, $arFilter, false);
//        $arResult["NAV_STRING"] = $rsElement->GetPageNavStringEx($arParams["PAGER_DESC_NUMBERING"], $arParams["PAGER_TITLE"], $arParams["PAGER_TEMPLATE"], $arParams["PAGER_SHOW_ALWAYS"], $arParams["PAGER_DESC_NUMBERING_CACHE_TIME"]);
//        $arResult["NAV_RESULT"] = $rsElement;

        while ($obElement = $rsElement->GetNextElement()) {
            $arItem = $obElement->GetFields();
            $arItem["PROPERTIES"] = $obElement->GetProperties();
            $arItem["AUTHOR"] = self::GetAuthor($arItem["PROPERTIES"]["USER"]["VALUE"], $arItem);
            $arItem["PUBLISH_TEXT"] = self::GetText($arItem["~PREVIEW_TEXT"]);
            if ($this->arParams["MAX_DEPTH"] && ($this->arParams["MAX_DEPTH"] > $arItem["PROPERTIES"]["DEPTH"]["VALUE"])) {
                $arItem["CHILDS"] = self::GetTree($arItem["ID"],  $arSelect, $sort);
            }
            $this->arResult["ITEMS"][] = $arItem;
            $this->arResult["ELEMENTS"][] = $arItem["ID"];

        }

    }
    public function GetTree($id, $arSelect = array(), $sort = array() )
    {
        if (!CModule::IncludeModule("iblock")) die();

        $arResult = array();
        $arFilter = array(
            "IBLOCK_ID" => $this->arParams['IBLOCK_ID'],
            "PROPERTY_OBJECT" => $this->arParams["OBJECT_ID"],
            "PROPERTY_PARENT" => $id,
            "ACTIVE" => "Y",
        );
        foreach (array("DATE_CREATE") as $s) {
            if (!in_array($s, $arSelect))
                $arSelect[] = $s;
        }
        $rsElement = CIBlockElement::GetList($sort, $arFilter, false, $arSelect);
        while ($obElement = $rsElement->GetNextElement()) {
            $arItem = $obElement->GetFields();
            $arItem["PUBLISH_DATE"] = CIBlockFormatProperties::DateFormat($this->arParams["ACTIVE_DATE_FORMAT"], MakeTimeStamp($arItem["DATE_CREATE"], CSite::GetDateFormat()));
            $arItem["PROPERTIES"] = $obElement->GetProperties();
            $arItem["AUTHOR"] = self::GetAuthor($arItem["PROPERTIES"]["USER"]["VALUE"], $arItem);
            $arItem["PUBLISH_TEXT"] = self::GetText($arItem["~PREVIEW_TEXT"]);

            if ($this->arParams["MAX_DEPTH"] && ($this->arParams["MAX_DEPTH"] > $arItem["PROPERTIES"]["DEPTH"]["VALUE"])) {
                $arItem["CHILDS"] = self::GetTree($arItem["ID"], $arSelect, $sort);
            }

            $this->arResult[] = $arItem;
        }
        //return $arResult;
    }
    // Комментарии и дочерние комментарии end



    //для текста start
    public function GetText($text)
    {
        return self::ParseText($text);
    }
    public function ParseText($text = "", $arParams = array())
    {
        while (preg_match("#\[quote\](.*?)\[/quote\]#si", $text))
            $text = preg_replace("#\[quote\](.*?)\[/quote\]#si", '<table class="quote"><thead><tr><th></th></tr></thead><tbody><tr><td>\1</td></tr></tbody></table>', $text);

        $text = preg_replace("#\[code\](.*?)\[/code\]#si", '<div class="code">\1</div>', $text);
        preg_match_all('#<div class="code">(.*?)</div>#si', $text, $code);

        $items = $code[0];

        $values = array();
        foreach ($items as $key => $val)
            $values[] = "#$" . $key . "#";

        $text = str_replace($items, $values, $text);

        // Parse BB
        $search[] = "#\[b\](.*?)\[/b\]#si";
        $search[] = "#\[i\](.*?)\[/i\]#si";
        $search[] = "#\[s\](.*?)\[/s\]#si";
        $search[] = "#\[u\](.*?)\[/u\]#si";
        $search[] = "#\[IMG\](.*?)\[/IMG\]#si";
        $search[] = "#\[url=(.+?)\](.+?)\[\/url\]#is";
        $search[] = "#\[url\](.+?)\[\/url\]#is";
        $replace[] = '<strong>\1</strong>';
        $replace[] = '<i>\1</i>';
        $replace[] = '<strike>\1</strike>';
        $replace[] = '<u>\1</u>';
        $replace[] = '<div><img style="max-width: 275px; max-height: 275px; padding: 5px 0 5px 0; clear: both;" src="\1"></div>';
        $replace[] = "<a href='\\1'>\\2</a>";
        $replace[] = "<a href='\\1'>\\1</a>";
        $text = preg_replace($search, $replace, $text);

        //$text = preg_replace('#\[url=(https?|ftp)://(\S+[^\s.,>!?])\](.*?)\[\/url\]#si', '<a '.$arParams["NO_FOLLOW"].' href="http://$2">$3</a>', $text);

        //if ($arParams["SHOW_FILEMAN"] == 0)
        //$text = preg_replace("#(https?|ftp)://\S+[^\s.,>)\];'\"!?]#",'<a '.$arParams["NO_FOLLOW"].' href="\\0">\\0</a>',$text);

        $text = str_replace($values, $items, $text);

        return $text;
    }
    //для текста end


    //автор коммента
    public function GetAuthor($user_id = 0, $arItem = array())
    {
        $result = array();
        if ($user_id <= 0 && $arItem["PROPERTIES"]["USER"]["VALUE"])
            $user_id = $arItem["PROPERTIES"]["USER"]["VALUE"];
        if ($user_id > 0) {
            $user = CUser::GetByID($user_id)->Fetch();
            if ($user) {
                $result["ID"] = $user_id;
                $result["NAME"] = ($user["NAME"] ? $user["NAME"] : $user["LOGIN"]);
                $result["FULL_NAME"] = ($user["NAME"] || $user["LAST_NAME"] ? $user["NAME"] . ($user["NAME"] && $user["LAST_NAME"] ? " " : "") . $user["LAST_NAME"] : $user["LOGIN"]);
                $result["ALL"] = $user;
            }
        }
        if ($user_id <= 0)
            $user_id = 0;
        if (!$result) {
            $result["ID"] = $user_id;
            $result["NAME"] = $arItem["PROPERTIES"]["NONUSER"]["VALUE"];
            $result["FULL_NAME"] = $arItem["PROPERTIES"]["NONUSER"]["VALUE"];
            $result["ALL"] = array();
        }
        return $result;
    }

    //кодировка
    public function CheckEncode($str)
    {
        $a = CSite::GetByID(SITE_ID)->GetNext();
        if (strtolower($a["CHARSET"]) !== "utf-8") {
            $str = mb_convert_encoding($str, "windows-1251", "UTF-8");
        }
        return $str;
    }

    public function CommentsReady()
    {

        foreach ($_POST as $key => $val)
            $arResult["POST"][$key] = htmlspecialcharsbx(self::CheckEncode(trim($val)));

        if (!$arResult["POST"]["NONUSER"] && isset($_COOKIE["COMMENT_NOUSER"]))
            $arResult["POST"]["NONUSER"] = htmlspecialcharsbx(trim($_COOKIE["COMMENT_NOUSER"]));

        $this->arResult["USER"];
        if ($arResult["USER"]["ID"]) {
            $arResult["POST"]["NONUSER"] = $arResult["USER"]["FULL_NAME"];
        }
        $errors = array();
        $success = false;
        if (strlen($arResult["POST"]["ACTION"]) > 0) {
            if ($arResult["POST"]["ACTION"] == "add") {
                if (!$arResult["POST"]["NONUSER"])
                    $errors[] = "Что то не так,е-мое";
            }

            setcookie("COMMENT_NOUSER", $arResult["POST"]["NOUSER"], time() + 3600 * 24, "/");


            switch ($arResult["POST"]["ACTION"]) {
                case "add":
                    if (self::Add([
                            "object" => $this->arParams["OBJECT_ID"],
                            "parent" => $arResult["POST"]["PARENT"],
                            "level" => $arResult["POST"]["DEPTH"],
                            "text" => $arResult["POST"]["MESSAGE"],
                            "author" => $arResult["USER"]["ID"],
                            "nonuser" => $arResult["POST"]["NONUSER"],
                        ]
                    )) {
                        $success = 1;
                    }
                    break;

                case "update":
                    if (self::Update(intval($arResult["POST"]["COM_ID"]), $arResult["POST"]["MESSAGE"])) {
                        $success = 2;
                    }
                    break;

                case "delete":
                    if (self::Delete(intval($arResult["POST"]["COM_ID"]))) {
                        $success = 3;
                    }
                    break;

            }
            $arResult["SUCCESS"] = $success;
        }

    }

//подключаем компонент
    public function executeComponent()
    {
        $this->Show();

        //$this->GetTree();
        //$this->GetAuthor();

        $this->CommentsReady();
        //раскоментить и обновить страницу с компонентом чтобы автоматически создать инфоблок с нужными полями и свойствами
        //$this->CreateIBlock();
        $this->loadAjax();
        $this->loadJQuery();
        $this->configureActions();
        $this->includeComponentTemplate();
    }
}