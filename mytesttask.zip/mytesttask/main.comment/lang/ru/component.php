<?
$MESS["MAIN_COMMENT_IBLOCK_MODULE_NOT_INSTALLED"] = "Модуль Информационных блоков не установлен.";
$MESS["MAIN_COMMENT_MODULE_NOT_INSTALLED"] = "Модуль Комментарии не установлен.";
$MESS["MAIN_COMMENT_CAPTCHA_WRONG"] = "Неверно указан код защиты от автоматических сообщений.";
$MESS["MAIN_COMMENT_CAPTHCA_EMPTY"] = "Не указан код защиты от автоматических сообщений.";
$MESS["MAIN_COMMENT_AVATAR_WRONG"] = "Неверный файл аватара.";
$MESS["MAIN_COMMENT_EMAIL_WRONG"] = "Неверно указан e-mail.";
$MESS["MAIN_COMMENT_EMAIL_EMPTY"] = "Не указан e-mail.";
$MESS["MAIN_COMMENT_NONUSER_EMPTY"] = "Не указано имя.";
$MESS["MAIN_COMMENT_MESSAGE_EMPTY"] = "Не введено сообщение.";
$MESS["MAIN_COMMENT_SUC_MODER"] = "Комментарий отправлен на модерацию.";
$MESS["MAIN_COMMENT_SUC_ADD"] = "Комментарий успешно добавлен.";
$MESS["MAIN_COMMENT_SUC_UPDATE"] = "Комментарий успешно изменен.";
$MESS["MAIN_COMMENT_SUC_DELETE"] = "Комментарий успешно удален.";
$MESS["MAIN_COMMENT_LEGAL_WRONG"] = "Не приняты условия правил комментирования.";
$MESS["MAIN_COMMENT_LEGAL_TEXT_DEFAULT"] = "Я согласен с правилами размещения сообщений на сайте.";
?>