<?
$MESS["MAIN_COMMENT_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["MAIN_COMMENT_NAME"] = "Комментарии";
$MESS["MAIN_COMMENT_DELETE"] = "Удалить";
$MESS["MAIN_COMMENT_COMMENT"] = "Комментировать";
$MESS["MAIN_COMMENT_EDIT"] = "Редактировать";
$MESS["MAIN_COMMENT_EDIT_FORM_NAME"] = "Редактировать отзыв";
$MESS["MAIN_COMMENT_MESSAGE"] = "Текст сообщения";
$MESS["MAIN_COMMENT_SAVE"] = "Сохранить";
$MESS["MAIN_COMMENT_ADD_NAME"] = "Написать отзыв";
$MESS["MAIN_COMMENT_FNAME"] = "Ваше имя";
$MESS["MAIN_COMMENT_ADD"] = "Добавить";
$MESS["MAIN_COMMENT_DEL_MESS"] = "Уверены, что хотите удалить комментарий? ВНИМАНИЕ: все дочерние комментарии тоже будут удалены!";
$MESS["MAIN_COMMENT_BACK_BUTTON"] = "Закрыть";
?>