<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
IncludeTemplateLangFile(__FILE__);
//if($USER->IsAdmin()) { echo "<pre>"; print_r($arParams); print_r($arResult); echo "</pre>"; die(); }

/** @var array $arParams */
/** @var array $arItem */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */


function ShowCommentsTree($arItem, $arParams, $arResult)
{
    echo '<pre>';
    $arItem;
    //print_r($arItem);
    //print_r($arResult[$itemid]);
    echo '</pre>';
	?>
	<div class="stock">
		<div class="userInfo">
			<span><?=$arItem["TIMESTAMP_X"]?> | <?=$arItem["NAME"]?></span>
		</div>

		<div class="userText">
			<p>
				<?=$arItem["PUBLISH_TEXT"]?>
			</p>
			<div class='action'>
					<a href="javascript:void(0);" onclick='comment_add(this, <?=$arItem["ID"]?>); return false;' title='<?=GetMessage("MAIN_COMMENT_COMMENT")?>'><?=GetMessage("MAIN_COMMENT_COMMENT")?></a>

					<a href="javascript:void(0);" onclick='comment_edit(this, <?=$arItem["ID"]?>); return false;' title="<?=GetMessage("MAIN_COMMENT_EDIT")?>"><?=GetMessage("MAIN_COMMENT_EDIT")?></a>

					<a href='javascript:void(0)' onclick='comment_delete(this, <?=$arItem["ID"]?>, "<?=GetMessage("MAIN_COMMENT_DEL_MESS")?>"); return false;' title='<?=GetMessage("MAIN_COMMENT_DELETE")?>'><?=GetMessage("MAIN_COMMENT_DELETE")?></a>

					<div class="form comment form_for" id='edit_form_<?=$arItem["ID"]?>'<?=($arResult["POST"]["COM_ID"] == $arItem["ID"] && !$arResult["SUCCESS"] ? " style='display: block;'" : "")?>>
						<form enctype="multipart/form-data" action="<?=$GLOBALS["APPLICATION"]->GetCurUri()?>" method='POST' onsubmit='return comment_validate(this);'>
							<textarea name="MESSAGE" rows="10" placeholder='<?=GetMessage("MAIN_COMMENT_MESSAGE")?>'><?=$arItem["~PREVIEW_TEXT"]?></textarea>
							<input type='hidden' name='ACTION' value='update' />
							<input type='hidden' name='COM_ID' value='<?=$arItem["ID"]?>' />
							<input type="submit" value="<?=GetMessage("MAIN_COMMENT_SAVE")?>" />
							<a href="javascript:void(0)" onclick='comment_back(); return false;' style='margin-top: -25px; text-decoration: none;'><?=GetMessage("MAIN_COMMENT_BACK_BUTTON")?></a>
						</form>
					</div>

					<div class="form comment form_for" id='add_form_<?=$arItem["ID"]?>'<?=($arResult["POST"]["PARENT"] == $arItem["ID"] && !$arResult["SUCCESS"] ? " style='display: block;'" : "")?>>
						<form enctype="multipart/form-data" action="<?=$GLOBALS["APPLICATION"]->GetCurUri()?>" method='POST' onsubmit='return comment_validate(this);'>
							<input type="text" name='NONUSER' value='<?=$arResult["POST"]["NONUSER"]?>' <?=($arResult["USER"]["ID"] ? "readonly='readonly'" : "")?> placeholder="<?=GetMessage("MAIN_COMMENT_FNAME")?>" class="w-45" />

							<div class="clear pt10"></div>

							<textarea name="MESSAGE" rows="10" placeholder='<?=GetMessage("MAIN_COMMENT_MESSAGE")?>'></textarea>
							<input type='hidden' name='PARENT' value='<?=$arItem["ID"]?>' />
							<input type='hidden' name='ACTION' value='add' />
							<input type='hidden' name='DEPTH' value='<?=($arItem["PROPERTIES"]["DEPTH"]["VALUE"]+1)?>' />

							<input type="submit" value="<?=GetMessage("MAIN_COMMENT_ADD")?>" />
							<a href="javascript:void(0)" onclick='comment_back(); return false;' style='margin-top: -25px; text-decoration: none;'><?=GetMessage("MAIN_COMMENT_BACK_BUTTON")?></a>
						</form>
					</div>
			</div>
		</div>
		<?if (!empty($arItem["CHILDS"])) {?>
			<?foreach ($arItem["CHILDS"] as $item) {
                ShowCommentsTree($item, $arParams, $arResult);
			}?>
		<?}?>
	</div>
	<?
}
?>
<div class='main_comment' id='comment_container'>
	<?if (strlen($_POST["ACTION"]) > 0) $GLOBALS["APPLICATION"]->RestartBuffer();?>
	<h1><span><?=GetMessage("MAIN_COMMENT_NAME")?></span></h1>
	<p style='color: green; display: none;' class='suc'><?=$arResult["SUCCESS"]?></p>
	<p style='color: red; display: none;' class='err'><?=$arResult["ERROR_MESSAGE"]?></p>
	<div class="form comment main_form"<?=($arResult["POST"]["PARENT"] > 0 && !$arResult["SUCCESS"] ? " style='display: none;' " : "")?>>
			<form enctype="multipart/form-data" action="<?=$GLOBALS["APPLICATION"]->GetCurUri()?>" method='POST' onsubmit='return comment_validate(this);'>
				<input type="text" name='NONUSER' value='<?=$arResult["POST"]["NONUSER"]?>' <?=($arResult["USER"]["ID"] ? "readonly='readonly'" : "")?> placeholder="<?=GetMessage("MAIN_COMMENT_FNAME")?>" class="w-45" />

				<textarea name="MESSAGE" rows="10" placeholder='<?=GetMessage("MAIN_COMMENT_MESSAGE")?>'><?=$arResult["POST"]["MESSAGE"]?></textarea>
				<input type='hidden' name='PARENT' value='' />
				<input type='hidden' name='ACTION' value='add' />
				<input type='hidden' name='DEPTH' value='1' />

				<input type="submit" value="<?=GetMessage("MAIN_COMMENT_ADD")?>" />
			</form>

	</div>
	<?if ($arResult["ITEMS"]) {?>

		<div class="comments">
			<?
			foreach ($arResult["ITEMS"] as $k => $arItem)
			{
				echo ShowCommentsTree($arItem, $arParams, $arResult);
			}
			?>
		</div>

	<?}?>
	<?if (strlen($_POST["ACTION"]) > 0) die();?>
</div>